import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import SplashScreen from './screens/SplashScreen';
import OnboardingScreen from './screens/OnboardingScreen';
import LoginScreen from './screens/LoginScreen';
import DashboardScreen from './screens/DashboardScreen';
import KuberShieldScreen from './screens/pillars/KuberShieldScreen';
import PramaanScreen from './screens/pillars/PramaanScreen';
import AakashvaniScreen from './screens/pillars/AakashvaniScreen';
import RakshakPingScreen from './screens/pillars/RakshakPingScreen';
import TrinetraScreen from './screens/pillars/TrinetraScreen';
import SutraScreen from './screens/pillars/SutraScreen';
import CommandScreen from './screens/pillars/CommandScreen';
import ProfileScreen from './screens/ProfileScreen';
import Layout from './components/Layout';

function ProtectedRoutes() {
  const { user, loading } = useAuth();

  if (loading) return <SplashScreen />;
  if (!user) return <Navigate to="/login" replace />;

  return (
    <Layout>
      <Routes>
        <Route path="/dashboard" element={<DashboardScreen />} />
        <Route path="/kuber-shield" element={<KuberShieldScreen />} />
        <Route path="/pramaan" element={<PramaanScreen />} />
        <Route path="/aakashvani" element={<AakashvaniScreen />} />
        <Route path="/rakshak-ping" element={<RakshakPingScreen />} />
        <Route path="/trinetra" element={<TrinetraScreen />} />
        <Route path="/sutra" element={<SutraScreen />} />
        <Route path="/command" element={<CommandScreen />} />
        <Route path="/profile" element={<ProfileScreen />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
}

function AppRoutes() {
  const { user, loading } = useAuth();

  if (loading) return <SplashScreen />;

  return (
    <Routes>
      <Route path="/" element={<SplashScreen />} />
      <Route path="/onboarding" element={<OnboardingScreen />} />
      <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <LoginScreen />} />
      <Route path="/*" element={<ProtectedRoutes />} />
    </Routes>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </LanguageProvider>
  );
}
